# Vless-Heroku

## 概述

用于在 Heroku 上部署 vless+websocket+tls，支持 xray core。支持导入WinXray！！
vless 相比 vmess 性能更加优秀，占用资源更少，运行更加稳定。

## 镜像

经测试本镜像占用内存资源较低，运行稳定。

[![Deploy](https://www.herokucdn.com/deploy/button.png)](https://dashboard.heroku.com/new?template=https%3A%2F%2Fgithub.com%2FSaverFoods%2F2v-le)

## 注意

### 端口

`端口` 为 `443` 。

### alterId

`alterId` 为 `0` 。

### UUID

`UUID` 默认为 `9a5b43e5-ds33-4g52-ae49-d83f491wb3ed` 可自行设置。

### 路径


`WebSocket` 路径(配置文件中的 `path` )为 `/app` 。

